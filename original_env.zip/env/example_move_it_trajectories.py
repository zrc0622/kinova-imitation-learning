#!/usr/bin/env python3

import sys
import time
import rospy
import moveit_commander
import moveit_msgs.msg
from gazebo_msgs.srv import *
from geometry_msgs.msg import *
from math import pi
from control_msgs.msg import *
from trajectory_msgs.msg import *
import actionlib
from std_srvs.srv import Empty
from tf import TransformListener
from robot import Robot
from task import peg_in
from Gen3Env.gen3env import gen3env
import gym
from stable_baselines3  import TD3
import torch.nn as nn
# from BC_model import BehaviorCloningModel
import torch

# net
class BehaviorCloningModel(nn.Module):  # 搭建神经网络
    def __init__(self, input_dim, output_dim):
        super(BehaviorCloningModel, self).__init__()  # 继承自父类的构造
        self.fc = nn.Sequential(nn.Linear(input_dim, 128),
                                nn.ReLU(),
                                nn.Linear(128, 64),
                                nn.ReLU(),
                                nn.Linear(64, output_dim)
                                )  # 搭建网络，两层隐藏层

    def forward(self, x):  # 前向传播方法
        return self.fc(x)


def main():
  # env=gym.make(id='Pendulum-v1')
  env=gym.make(id='peg_in_hole-v0')
  env.reset()
  model_path = './model/model_epoch50000_mse_6r_256b_jue.pth'
  model = BehaviorCloningModel(4, 4)
  model.load_state_dict(torch.load(model_path))

  # absolute
  for episode in range(10):
    print("episode: {}".format(episode))
    env.robot.move(pose=[0.5, 0, 0.5])
    obs = env.reset()
    model_obs = obs[:4]
    done = False
    while not done:
      with torch.no_grad():
        action = model(torch.Tensor(model_obs)).numpy()
      next_obs,reward,done,_=env.step(action=action)
      print('reward={}'.format(reward))
      model_obs = next_obs[:4]
  env.robot.move(pose=[0.5, 0, 0.5])
  # model=TD3('MlpPolicy', env, verbose=1)
  # model.learn(total_timesteps=1000)

  # delt
  for episode in range(10):
    print("episode: {}".format(episode))
    env.robot.move(pose=[0.5, 0, 0.5])
    obs = env.reset()
    model_obs = obs[:4]
    done = False
    while not done:
      with torch.no_grad():
        action = model(torch.Tensor(model_obs)).numpy() + model_obs
      next_obs,reward,done,_=env.step(action=action)
      print('reward={}'.format(reward))
      model_obs = next_obs[:4]
  env.robot.move(pose=[0.5, 0, 0.5])
  
if __name__ == '__main__':
  main()
